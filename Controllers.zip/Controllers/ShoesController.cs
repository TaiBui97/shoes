﻿using ShoesStore_agforl.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ShoesStore_agforl.Controllers
{
    public class ShoesController : Controller
    {
        // GET: Shoes
        dbBANGiayDataContext data = new dbBANGiayDataContext();
        
        public ActionResult Laygiayton()        
        {
            var giay = data.SanPhams.OrderByDescending(a => a.SoLuongCon).Take(4);
            return PartialView("Laygiayton", giay);
        }
        public ActionResult Laygiaydac()
        {
            var giay = data.SanPhams.OrderByDescending(a => a.Gia).Take(4);
            return PartialView("Laygiaydac", giay);
        }

        public ActionResult Laygiaycu()
        {
            var giay = data.SanPhams.OrderBy(a => a.NgayLaySP).Take(4);
            return PartialView("Laygiaycu", giay);
        }

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult About()
        {
            return View();
        }
        
    }
}